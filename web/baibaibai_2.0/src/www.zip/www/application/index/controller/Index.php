<?php
/*
 * @Author: m1saka@x1ct34m
 * @blog: www.m1saka.love
 */
namespace app\index\controller;
class Index
{
    public function index()
    {
        return '<p>卷起来 不准摆！</p>
            <br><img src="http://www.m1saka.love/wp-content/uploads/2021/11/kaujuan.jpg" alt="kaijuan" />';
    }
}